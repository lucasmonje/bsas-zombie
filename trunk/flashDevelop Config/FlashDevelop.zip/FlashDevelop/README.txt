Before you customize any files here, be sure you have read the customization notes from the wiki:
http://www.flashdevelop.org/wikidocs/index.php?title=Configuration